function FormCondition()
{
    var sName = document.forms['BookForm']['Name'].value;
    var sEmail = document.forms['BookForm']['Email'].value;
    var sPhone = document.forms['BookForm']['Phone'].value;
    var nDate = document.forms['BookForm']['Date'].value;
    var nDays = document.forms['BookForm']['Days'].value;

    if(sName === "")
    {
        alert("Please input your name.");
        return false;
    }

    if (sEmail === "") 
    {
        alert("Please input your email.");
        return false;
    }

    if(isNaN(sPhone))
    {
        alert("Please input only numbers.");
        return false;
    }

    if(isNaN(nDays))
    {
        alert("Please input only numbers.");
        return false;
    }
}